# Cytrade project brain

Last seeded: 2026-05-24

## Current operating phase

The active workflow is `MainSealFollow` Level2 dry-run monitoring. The system should generate the stock pool before the open, start the market-only dry-run runtime, observe tick and Level2 subscriptions, and stop around noon. This phase is for validation and monitoring, not live trading.

## Core log markers

Use these markers to reconstruct a morning session:

- `MONITOR_SESSION pool_collect_start`
- `MONITOR_SESSION pool_generated`
- `MONITOR_SESSION monitor_start`
- `MONITOR_SESSION session_start`
- `Runtime heartbeat ... strategies=... tick_subscriptions=... l2_stocks=...`
- `MSF_EVENT {"event":"entry_signal_accepted", ...}`
- `MSF_EVENT {"event":"dry_run_probe_trade_recorded", ...}`
- `[ORDER] [TRADE] [MOCK] observation filled ...`
- `MONITOR_SESSION session_stop`
- `MONITOR_SESSION stopped ... real_order_sent=false`

## Minimum morning acceptance

- Stock pool generation succeeds and has `total > 0`.
- Runtime monitor starts.
- At least one heartbeat is emitted.
- After trading activation, `strategies > 0`.
- No non-mock order/trade line appears.
- Logs are sufficient for replay.

## First self-improving loop

The first loop should make the system easier to observe, test, and review:

1. Parse morning logs.
2. Generate a markdown report and JSON summary.
3. Propose 1-3 low-risk improvement tasks.
4. Give Codex CLI a constrained task prompt.
5. Run safety and quality gates.
6. Human reviews and approves changes.
7. Lessons are written back here and to `known_failures.yaml`.

## Boundaries

Agents may propose patches, but they must not automatically merge, deploy, enable real trading, alter credentials, alter account paths, or widen risk limits.
