# MainSealFollow lessons

Use this file to keep durable lessons from morning dry-run reviews.

## 2026-05-24 seed

The immediate unknowns are live trading-session validation points: strategy activation after 09:30, tick subscription growth, Level2 detail subscription growth, and a complete dry-run trigger chain. Prefer observability and replay improvements before strategy-parameter changes.
