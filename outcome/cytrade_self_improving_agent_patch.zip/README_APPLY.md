# cytrade self-improving agent patch

基线：`f238d0f Add stock-pool sources and dry-run monitor session`

这个增量包给当前工程增加第一版“自我进化智能体外层闭环”。它不修改真实交易路径，不开启实盘，不改策略阈值，不改账号、QMT 路径或本地密钥配置。

## 推荐安装方式：git apply

把 `cytrade_self_improving_agent.patch` 复制到工程根目录的上一级或任意位置，然后执行：

```bash
cd cytrade-main
git apply --check /path/to/cytrade_self_improving_agent.patch
git apply /path/to/cytrade_self_improving_agent.patch
```

Windows PowerShell 示例：

```powershell
cd C:\path\to\cytrade-main
git apply --check C:\path\to\cytrade_self_improving_agent.patch
git apply C:\path\to\cytrade_self_improving_agent.patch
```

如果你的本地工程没有 git，也可以把 `changed_files/` 里的内容覆盖到工程根目录。覆盖方式只适合与上述基线基本一致的工程。

## 新增能力

1. `AGENTS.md`：给 Codex CLI 和后续智能体的项目规则、安全边界、验证命令。
2. `agent/sensors/`：解析 MainSealFollow 日志、pytest 输出、git diff。
3. `agent/loops/post_morning_review.py`：盘后/午间自动生成 morning review 和改进任务。
4. `agent/loops/generate_improvement_tasks.py`：根据日志摘要生成 1-3 个低风险任务。
5. `agent/tools/codex_cli_runner.py`：为指定任务生成受约束的 Codex CLI prompt，默认只写 prompt，不执行。
6. `agent/gates/quality_gate.py`：执行安全扫描、py_compile、pytest 质量闸门。
7. `agent/memory/`：项目大脑、已知失败、运行报告和 Codex prompt 的落地目录。
8. `docs/SELF_IMPROVING_AGENT_SYSTEM.md`：使用说明和闭环设计。
9. `tests/test_agent_monitor_review.py`：新增 5 个测试覆盖日志解析、任务生成、安全扫描、pytest 输出解析。
10. `.gitignore`：忽略运行时产物 `config/main_seal_follow_pool.csv`。

## 应用后快速验证

```bash
python -m py_compile agent/sensors/parse_monitor_logs.py agent/sensors/parse_pytest_output.py agent/sensors/parse_git_diff.py agent/loops/post_morning_review.py agent/loops/generate_improvement_tasks.py agent/gates/quality_gate.py agent/tools/codex_cli_runner.py
python -m pytest tests/test_agent_monitor_review.py
python -m agent.gates.quality_gate --pytest tests/test_agent_monitor_review.py
```

## 早盘 dry-run 后使用

```bash
python -m agent.loops.post_morning_review --run-id 2026-05-25 --print-paths
```

它会生成：

- `agent/memory/runs/2026-05-25_morning.md`
- `agent/memory/runs/2026-05-25_morning_summary.json`
- `agent/memory/improvement_tasks.yaml`

给 Codex CLI 准备一个低风险任务 prompt：

```bash
python -m agent.tools.codex_cli_runner --task-id add-top-blocked-reason-summary
```

默认不会执行 Codex。确认 prompt 和任务后，才用 `--execute` 并配置本地 Codex 命令。

## 本次验证记录

已通过：

```text
python -m py_compile agent/sensors/parse_monitor_logs.py agent/sensors/parse_pytest_output.py agent/sensors/parse_git_diff.py agent/loops/post_morning_review.py agent/loops/generate_improvement_tasks.py agent/gates/quality_gate.py agent/gates/safety_gate.py agent/tools/codex_cli_runner.py agent/tools/test_runner.py
python -m pytest tests/test_agent_monitor_review.py -q
python -m agent.gates.quality_gate --diff-file cytrade_self_improving_agent.patch --pytest tests/test_agent_monitor_review.py
```

补丁应用校验已通过：

```text
git apply --check cytrade_self_improving_agent.patch
git apply cytrade_self_improving_agent.patch
python -m pytest tests/test_agent_monitor_review.py -q
```

受当前容器环境限制，原有 MainSealFollow 测试子集收集阶段缺少 `chinese_calendar` 依赖，未能在这里完整复跑。项目配置中已经声明 `chinese-calendar>=1.9`，在你的工程环境安装依赖后再跑完整测试即可。
