# Agent quality gate

Overall: **PASS**

## PASS - safety_scan

```text
no risky diff patterns found
```

## PASS - /opt/pyvenv/bin/python -m py_compile agent/sensors/parse_monitor_logs.py agent/sensors/parse_pytest_output.py agent/sensors/parse_git_diff.py agent/loops/post_morning_review.py agent/loops/generate_improvement_tasks.py agent/gates/quality_gate.py agent/tools/codex_cli_runner.py

```text
exit=0
```

## PASS - /opt/pyvenv/bin/python -m pytest tests/test_agent_monitor_review.py

```text
============================= test session starts ==============================
platform linux -- Python 3.13.5, pytest-9.0.2, pluggy-1.6.0 -- /opt/pyvenv/bin/python
cachedir: .pytest_cache
metadata: {'Python': '3.13.5', 'Platform': 'Linux-4.4.0-x86_64-with-glibc2.41', 'Packages': {'pytest': '9.0.2', 'pluggy': '1.6.0'}, 'Plugins': {'metadata': '3.1.1', 'ddtrace': '4.4.0', 'asyncio': '1.3.0', 'Faker': '40.1.2', 'anyio': '4.13.0', 'cov': '7.0.0', 'json-report': '1.5.0'}, 'PLATFORM': 'linux/amd64', 'CI': 'true'}
rootdir: /mnt/data/cytrade_new
configfile: pytest.ini
plugins: metadata-3.1.1, ddtrace-4.4.0, asyncio-1.3.0, Faker-40.1.2, anyio-4.13.0, cov-7.0.0, json-report-1.5.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
collecting ... collected 5 items

tests/test_agent_monitor_review.py::test_parse_monitor_logs_builds_morning_acceptance_summary PASSED [ 20%]
tests/test_agent_monitor_review.py::test_parse_monitor_logs_detects_possible_real_order_lines PASSED [ 40%]
tests/test_agent_monitor_review.py::test_generate_tasks_for_active_strategies_without_signals PASSED [ 60%]
tests/test_agent_monitor_review.py::test_quality_gate_safety_scan_blocks_dry_run_disablement PASSED [ 80%]
tests/test_agent_monitor_review.py::test_parse_pytest_output_summary_line PASSED [100%]

============================== 5 passed in 0.10s ===============================
```
